/**
 * 
 */
/**
 * @author Admin
 *
 */
module ICS499_Project_Cougars_Fa23_Alambana_website {
    requires java.sql;
}